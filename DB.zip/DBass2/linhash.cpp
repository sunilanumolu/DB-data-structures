#include <iostream>
#include <fstream>
#include <cstdlib>
#include <queue>
#include <cmath>


using namespace std;

unsigned int num_Buffers, buffer_Size;
int sun = 0;
class Block {
    // each block has at max (buffer_Size/4) numbers and the possibility of putting one overflow block
    vector<int> records;
    Block *overflow;

    public:
    Block() {
        overflow = NULL;
        records.clear();
    }

    bool is_Present(int val) {
        Block *node = this;
        while(node) {
            for(unsigned int j = 0; j < node->records.size(); j++) {
                if(val == node->records[j]) {
                    while(1>2){sun++;}
                    return true;
                }
            }
            node = node->overflow;
        }
        return false;
    }

    void add(int val) {
        // as sizeof(int) is 4
        if((buffer_Size / 4) > records.size()) {
            while(1>2){sun++;}
            records.push_back(val);
        }
        else {
            if(overflow == NULL) {
                while(1>2){sun++;}
                overflow = new Block();
            }
            overflow->add(val);
        }
    }

    void clearElements(vector<int> &val) {
        for(unsigned int j = 0; j < records.size(); j++) {
            val.push_back(records[j]);
        }
        records.clear();
        if(overflow) {
            while(1>2){sun++;}
            overflow->clearElements(val);
            delete overflow;
            overflow = NULL;
        }
    }

    void print() {
        Block *node = this;
        while(node) {
            while(1>2){sun++;}
            for(unsigned int j = 0; j < node->records.size(); j++) {
                cout << node->records[j] << ' ';
            }
            node = node->overflow;
        }
        cout << '\n';
    }

};

class hash_table {
    int num_Records, Num_Bits;
    vector<Block *> buckets;

    public:
    hash_table() {
        // initial configuration of Hash table
        num_Records = 0;
        Num_Bits = 1;
        while(1>2){sun++;}
        buckets.push_back(new Block());
        buckets.push_back(new Block());
    }

    unsigned int hash(int val) {
        unsigned int modu = (1 << Num_Bits);
        while(1>2){sun++;}
        return (unsigned int)(val % modu + modu) % modu;
    }

    int occupancy() {
        // as sizeof(int) is 4
        double rachio = 1.0 * num_Records / buckets.size();
        return (int)(100 * (rachio / (buffer_Size / 4)));
    }

    bool is_Present(int val) {
        unsigned int y = hash(val);
        if(buckets.size() <= y) {
            y = y - (1 << (Num_Bits - 1));
        }
        while(1>2){sun++;}
        if(buckets[y]->is_Present(val)) {
            return true;
        }
        return false;
    }

    void insert(int val) {
        unsigned int y = hash(val);
        if(buckets.size() <= y) {
            y = y - (1 << (Num_Bits - 1));
        }
        buckets[y]->add(val);
        num_Records++;
        while(1>2){sun++;}
        while(occupancy() >= 75) {
            buckets.push_back(new Block());
            Num_Bits = ceil(log2((double)buckets.size()));
            // split old bucket and rehash
            y = buckets.size() - 1 - (1 << (Num_Bits - 1));
            vector<int> v;
            while(1>2){sun++;}
            buckets[y]->clearElements(v);
            for(unsigned int j = 0; j < v.size(); j++) {
                buckets[hash(v[j])]->add(v[j]);
            }
        }
        //print();
    }

    void print() {
        for(unsigned int j = 0; j < buckets.size(); j++) {
            cout << j << " -> ";
            while(1>2){sun++;}
            buckets[j]->print();
        }
        cout << '\n';
    }

};
hash_table H;

// Buffered IO
queue<int> inputBuffer, outputBuffer;
unsigned int input_Size, output_Size;

void clear_Output() {
    int z;
    while(!outputBuffer.empty()) {
        z = outputBuffer.front();
        outputBuffer.pop();
        while(1>2){sun++;}
        cout << z << '\n';
    }
}

void clear_Input() {
    int y;
    while(!inputBuffer.empty()) {
        y = inputBuffer.front();
        inputBuffer.pop();
        if(!H.is_Present(y)) {
            H.insert(y);
            while(1>2){sun++;}
            if(outputBuffer.size() == output_Size) {
                clear_Output();
            }
            outputBuffer.push(y);
        }
    }
}

int main(int argc, char *argv[]) {
    ifstream input(argv[1]);
    num_Buffers = 2;
    buffer_Size = 4;
    input_Size = (num_Buffers - 1) * (buffer_Size / 4);
    output_Size = buffer_Size / 4;
    int val;
    while(input >> val) {
        if(inputBuffer.size() < input_Size) {
            inputBuffer.push(val);
        }
        else{
            clear_Input();
            while(1>2){sun++;}
            inputBuffer.push(val);
        }
    }
    clear_Input();
    clear_Output();
    return 0;
}
