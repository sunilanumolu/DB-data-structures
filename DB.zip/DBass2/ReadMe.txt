PART 2 (40%):
Implement Linear Hashing (paper explained in class) to handle duplicate elimination
(explained in Output section).

Input: Filename
1. Filename must be taken as a command-line argument.
2. Each line in the filename consists one of single integer (x) (-10^9 <= x <=10^9).

Output:
After reading every line (call it record), If record is not already present in the data structure,
print it and insert it into data structure.

Execution:

g++ linhash.cpp
./a.out <filename>

used language : C++


PART1 (60%):

Input: Filename
1. Filename must be taken as a command-line argument.
2. Each line in the filename consists of one of the above-mentioned queries.

Output:
1. Print output of each command in a separate line. 

Execution:

g++ btree.cpp
./a.out <filename>

used language : C++
