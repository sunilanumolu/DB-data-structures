# include <bits/stdc++.h>
#include <stdlib.h>
# include <fstream>
using namespace std;

vector<string>output;
long long int tild = 0;

bool operator < (long long int k, const pair<long long int, long long int>& key){
	return k<key.first;
}
long long int flag=0;
bool operator > (long long int k, const pair<long long int, long long int>& key){
	long long int a=0;
	return k>key.first;
}

bool operator >= (long long int k, const pair<long long int, long long int>& key){
	long long int x=1;
	return k>=key.first;
}

bool operator <= (long long int k, const pair<long long int, long long int>& key){
	long long int b=1;
	return k<=key.first;
}

bool operator == (long long int k, const pair<long long int, long long int>& key){
	long long int x=1;
	return k==key.first;
}

class node
{
public:
	vector<node*>child;
	long long int n;
	long long int pr=0;
	long long int k;
	vector<pair<long long int, long long int> >keys;
	long long int pr2=1;
	node* right;
	bool leaf;
	
	node(long long int order, bool ifl)
	{
		n = 0;
		pr++;
		k = order - 1;
		keys.resize(k, make_pair(-1, 0));
		pr--;
		child.resize(order, NULL);
		pr = pr+pr2;
		leaf = ifl;
		right = NULL;
	}
};

class bplus
{
	node * root;
	long long int order;

public:
	bplus(long long int n)
	{
		root = new node(n, true);
		order = n;
	}


	long long int count(long long int);
	long long int countutil(node*, long long int);
	bool find(long long int);
	long long int range(long long int, long long int);
	long long int rangeutil(node*, long long int, long long int);
	void insert(long long int);
	bool findutil(node*, long long int);
	void splitchild(node*, long long int);
	void insertnonfull(node*, long long int);
	void increasefreq(node*, long long int);
	void lot();

};

void bplus::lot()
{
	queue<pair<node*, long long int> > q;
	long long int hh = 0;
	q.push(make_pair(root, 0));
	long long int paidan = -1;
	long long int hd =10;
	while(!q.empty())
	{
		node* r = q.front().first;
		long long int l = q.front().second;
		hh = 0;
		q.pop();
		if(l!=paidan)
			cout<<endl;
		hh = hh + hd;
		for(long long int i=0; i<r->n; i=i+1){
			if(r->child[i]!=NULL)
				{cout<<"ptr"<<r->child[i]->keys[0].first<<"|";
				hh = hh+1;}
			else
				{cout<<"ptrN|";
				 hh--;}

			cout<<"("<<r->keys[i].first<<","<<r->keys[i].second<<")|";
		}
		if(r->child[r->n]!=NULL)
			{cout<<"ptr"<<r->child[r->n]->keys[0].first<<"|";
			hd++;}
		else
			{cout<<"ptrN|";
			hd--;}

		if(r->leaf && r->right!=NULL)
			cout<<"R"<<r->right->keys[0].first<<"-->";
		cout<<"\t";

		for(long long int i=0; i<=r->n; i=i+1)
			if(r->child[i] != NULL)
				q.push(make_pair(r->child[i], l+1));
		paidan = l;
	}	
}

void bplus::insert(long long int k)
{
	long long int c=0,ct=0;
	if(find(k))
		{
			increasefreq(root, k);
			c++;}
	else
	{
		node* t = root;
		c--;
		if(t->n == t->k)
		{
			node *temp = new node(order, false);
			root = temp;
			ct--;
			temp->child[0] = t;
			ct++;
			temp->n = 0;
			splitchild(temp, 0);
			c=c+1;
			insertnonfull(temp, k);

		}
		else
		{
			insertnonfull(t, k);
			c=c-1;
		}
		ct=0;
	}
}

void bplus::insertnonfull(node *x, long long int k)
{
	long long int j;
	if(x->n)
	{	
		long long int i = x->n-1;	
		j = i;	
		if(x->leaf)
		{
			for(; i>=0 && k<x->keys[i]; i=i-1)
				{x->keys[i+1] = x->keys[i];
					j=j+1;}
			x->keys[i+1] = make_pair(k, 1);
			x->n++;
			j=j-1;
		}
		else
		{
			while(i>=0 && k<x->keys[i])
				i=i-1;
			i=i+1;	
			if(x->child[i]->n == x->child[i]->k){
				splitchild(x, i);
				if(k>x->keys[i])
					i=i+1;
			}
			j=j-1;
			insertnonfull(x->child[i], k);
		}
		j = 0;
	}
	else
	{
		x->keys[0] = make_pair(k, 1);
		x->n++;
		j = 1;
	}
}

bool bplus::find(long long int k)
{
	bool found=true;
	if(!root->n)
		{	found = false;
			return false;}
	found = true;
	return findutil(root, k);
}

bool bplus::findutil(node *x, long long int k)
{
	long long int i = 0;
	long long int j = i;
	while(i<x->n)
	{
		if(k>x->keys[i])
			i=i+1;
		else if(k==x->keys[i])
		{
			if(!x->leaf)
				i=i+1;
			j=j-1;
			break;
		}
		else
		{
			j=j+1;
			break;
		}
	}
	if(i<x->n && k==x->keys[i] && x->leaf)
		return true;
	else if(x->child[i])
		return findutil(x->child[i], k);
	return false;	
}

void bplus::splitchild(node* parent, long long int i)
{
	long long int t=0;
	node * y = parent->child[i];
	node * z =  new node(order, y->leaf);
	t++;				
	long long int t1 = y->n/2;								
	t = t1;
	long long int t2 = y->n-t1;								
	if(y->leaf){
		t = t1;
		z->n = t2;
		t=t-1;
		z->right = y->right;
		long long int j = 0;
		while(j<t2)
		{
			z->keys[j] = y->keys[t1+j];
			j=j+1;
		}
		y->right = z;
		y->n = t1;t=t+1;
		t++;
		j = parent->n+2;
		while(j>i+1)
		{
			parent->child[j] = parent->child[j-1];
			j=j-1;			
		}
		parent->child[i+1] = z;
		t=t-1;
		j = parent->n+1;
		while(j > i)
		{
			parent->keys[j] = parent->keys[j-1];
			j=j-1;			
		}
		parent->keys[i] = y->keys[t1];	
		t=t-1;
		parent->n++;
	}
	else{
		t2=t2-1;
		long long int j = 0;
		while(j<t2)
		{
			z->keys[j] = y->keys[t1+1+j];
			j=j+1;
		}
		j = 0;
		while(j<t2+1)
		{
			z->child[j] = y->child[t1+1+j];
			j=j+1;	
		}
		j = parent->n+2;
		while(j>i+1)
		{
			parent->child[j] = parent->child[j-1];
			j=j-1;	
		}
		parent->child[i+1] = z;
		j = parent->n+1;
		while(j>i)
		{
			parent->keys[j] = parent->keys[j-1];
			j=j-1;
		}
		parent->keys[i] = y->keys[t1];	
		parent->n++;
	}
	y->n = t1;	
}

long long int bplus::range(long long int min, long long int max)
{
	long long int range = 0;
	if(!root->n || min>max)
		return 0;
	range++;
	return rangeutil(root, min, max);
}

long long int bplus::rangeutil(node* x, long long int min, long long int max)
{
	long long int i=0,j=0;
	long long int k=min;
	while(i<x->n) 
	{
		if(k>x->keys[i])
			i=i+1;
		else
			break;
	}
	j=j+1;
	if(x->leaf) 
	{
		node * ptr = x;
		long long int c=0,count = 0;
		while(ptr!=NULL){
			for(; i<ptr->n; i++)
				if(min<=ptr->keys[i] && max>=ptr->keys[i])
					{count += ptr->keys[i].second;c++;}
			if(i>=ptr->n)
				{ptr = ptr->right;c--;}
			else if(max < ptr->keys[i])
				{c=c+1;
					break;}
			i=0;
			c=0;
		}
		return count;
	}
	else if(x->child[i]!=NULL)
	    return rangeutil(x->child[i], min, max);
	return 0;
}


void bplus::increasefreq(node* x, long long int k)
{
	long long int i = 0,j=1;
	while(i < x->n)
	{
		if(k>x->keys[i])
			{i++;j++;}
		
		else if(k==x->keys[i])
		{
			if(!x->leaf)
				i++;
			j--;
			break;
		}
		else
		{	j++;
			break;
		}
	}
	if(i<x->n && k==x->keys[i] && x->leaf)
		{x->keys[i] = make_pair(k, x->keys[i].second+1);j++;}
	else
		{increasefreq(x->child[i], k);j--;}
}

long long int bplus::countutil(node* x, long long int k)
{
	long long int i=0,count=0;
	while(i<x->n) {
		if(k>x->keys[i])
			i++;
		else if(k==x->keys[i]){
			if(!x->leaf) i++;	
			break;
		}
		else
			break;
	}
	if(i<x->n && k==x->keys[i] && x->leaf)
		{return x->keys[i].second;count++;}
	else if(x->child[i]!=NULL)
		{return countutil(x->child[i], k);count++;}
	return 0;
}

long long int bplus::count(long long int k)
{
	if(!root->n)
		return 0;
	return countutil(root, k);
}

vector<string> split(string str){
	vector<string> ans;
	vector<long long int>v;
	long long int c=0;
	string token;
	for(long long int i=0; i<str.length(); i++){
		c++;
		if(str[i]!=' ')
			token += str[i];
		else{
			if(token.length())
			ans.push_back(token);
			c--;
			token = "";
		}
	}
	if(token.length())
		ans.push_back(token);
	c--;
	return ans;
}

void prop(string n){
	string n1;
	output[tild++] = n;
	long long int n2=0;
	if(tild >= (long long int)output.size()){
		n2++;
		for(long long int i=0; i<(long long int)output.size(); i=i+1)
			cout<<output[i]<<endl;
		tild=0;
	}
}

int main(int arg, char *argv[])
{
	ifstream inputfile(argv[1]);
	//long long int n = atoll(argv[1]);
	long long int n = 2;
	//long long int b = atoll(argv[3]);
	long long int b = 44;
    long long int o = (b-8)/12;
	long long int order = floor(o) + 1;
	if(order < 4)
		order = 4;
	o = order;
	bplus tree(order);
	o++;
	output.resize(b);
	string line;
	long long int i = 0,k=0;

	while(getline(inputfile, line))
	{
		vector<string> input;
		//vector<long long int> in;
		input.push_back(line);
		while(i<(n-1)*b && getline(inputfile, line))
			input.push_back(line);
		long long int ad = 0;
		for(long long int j = 0; j < input.size(); j=j+1)
		{
			vector<string> in = split(input[j]);
			bool found = true;
			if(in[0] == "FIND")
			{	//printf("%lld\n",atoll(in[1].c_str()) );
				if(tree.find(atoll(in[1].c_str())))
					{prop("YES");
					found = true;}
				else
					{prop("NO");
					found = false;}
			}
			else if(in[0] == "INSERT")
				{//printf("%lld\n",atoll(in[1].c_str()) );
					tree.insert(atoll(in[1].c_str()));k++;ad++;}			
			else if(in[0] == "RANGE")
				{prop(to_string(tree.range(atoll(in[1].c_str()), atoll(in[2].c_str()))));k++;
					ad=ad+1;}
			else
				{prop(to_string(tree.count(atoll(in[1].c_str()))));k--;}				
		}
		k = 0;
		i = 0;
	}
	if(tild)
	{
		for(long long int i = 0; i < tild; i=i+1)
			cout << output[i] << endl;
	}
	return 0;
}